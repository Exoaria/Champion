package au.exoaria.champion;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class ChampionListener implements Listener {

	public static HashMap<String, Long> playerLoginTime = new HashMap<String, Long>();

	@EventHandler(priority = EventPriority.HIGH)
	public void hashname(PlayerJoinEvent joinEvent) {
		String player = joinEvent.getPlayer().getName();
			times.put(player, System.currentTimeMillis());
	}
}
